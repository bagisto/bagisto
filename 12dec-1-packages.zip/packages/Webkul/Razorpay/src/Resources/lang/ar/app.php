<?php

return [
    'drop-in-ui' => [
        'title' => 'رايزورباي',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'تم إلغاء دفعة Razorpay.',
        ],

        'something-went-wrong'     => 'حدث خطأ ما.',
        'supported-currency-error' => 'العملة :currency غير مدعومة. العملات المدعومة هي: :supportedCurrencies.',
    ],
];
