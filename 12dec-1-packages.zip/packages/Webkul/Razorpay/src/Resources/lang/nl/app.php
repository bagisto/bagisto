<?php

return [
    'drop-in-ui' => [
        'title' => 'Razorpay',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'De Razorpay-betaling is geannuleerd.',
        ],

        'something-went-wrong'     => 'Er is iets misgegaan.',
        'supported-currency-error' => 'Valuta :currency wordt niet ondersteund. Ondersteunde valuta\'s: :supportedCurrencies.',
    ],
];
