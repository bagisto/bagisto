<?php

return [
    'drop-in-ui' => [
        'title' => 'Razorpay',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'Платіж Razorpay було скасовано.',
        ],

        'something-went-wrong'     => 'Щось пішло не так.',
        'supported-currency-error' => 'Валюта :currency не підтримується. Підтримувані валюти: :supportedCurrencies.',
    ],
];
