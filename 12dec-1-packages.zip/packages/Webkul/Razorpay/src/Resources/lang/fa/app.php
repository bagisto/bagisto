<?php

return [
    'drop-in-ui' => [
        'title' => 'رازورپی',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'پرداخت Razorpay لغو شد.',
        ],

        'something-went-wrong'     => 'مشکلی پیش آمد.',
        'supported-currency-error' => 'ارز :currency پشتیبانی نمی‌شود. ارزهای پشتیبانی شده: :supportedCurrencies.',
    ],
];
