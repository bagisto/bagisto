<?php

return [
    'drop-in-ui' => [
        'title' => 'Razorpay',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'Razorpay ödemesi iptal edildi.',
        ],

        'something-went-wrong'     => 'Bir şeyler ters gitti.',
        'supported-currency-error' => 'Para birimi :currency desteklenmiyor. Desteklenen para birimleri: :supportedCurrencies.',
    ],
];
