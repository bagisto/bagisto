<?php

return [
    'drop-in-ui' => [
        'title' => 'רייזורפיי',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'התשלום ב-Razorpay בוטל.',
        ],

        'something-went-wrong'     => 'משהו השתבש.',
        'supported-currency-error' => 'המטבע :currency אינו נתמך. מטבעות נתמכים: :supportedCurrencies.',
    ],
];
