<?php

return [
    'drop-in-ui' => [
        'title' => 'Razorpay',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'O pagamento do Razorpay foi cancelado.',
        ],

        'something-went-wrong'     => 'Algo deu errado.',
        'supported-currency-error' => 'A moeda :currency não é suportada. Moedas suportadas: :supportedCurrencies.',
    ],
];
