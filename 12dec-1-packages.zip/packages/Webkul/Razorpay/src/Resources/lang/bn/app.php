<?php

return [
    'drop-in-ui' => [
        'title' => 'রেজারপে',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'Razorpay পেমেন্ট বাতিল করা হয়েছে।',
        ],

        'something-went-wrong'     => 'কিছু ভুল হয়েছে।',
        'supported-currency-error' => 'মুদ্রা :currency সমর্থিত নয়। সমর্থিত মুদ্রাসমূহ: :supportedCurrencies.',
    ],
];
