<?php

return [
    'drop-in-ui' => [
        'title' => 'Razorpay',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'Платёж Razorpay был отменён.',
        ],

        'something-went-wrong'     => 'Что-то пошло не так.',
        'supported-currency-error' => 'Валюта :currency не поддерживается. Поддерживаемые валюты: :supportedCurrencies.',
    ],
];
