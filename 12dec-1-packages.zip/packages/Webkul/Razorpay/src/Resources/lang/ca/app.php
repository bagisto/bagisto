<?php

return [
    'drop-in-ui' => [
        'title' => 'Razorpay',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'El pagament de Razorpay ha estat cancel·lat.',
        ],

        'something-went-wrong'     => 'Alguna cosa ha anat malament.',
        'supported-currency-error' => 'La moneda :currency no és compatible. Monedes compatibles: :supportedCurrencies.',
    ],
];
