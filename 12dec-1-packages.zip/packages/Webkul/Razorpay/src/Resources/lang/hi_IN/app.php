<?php

return [
    'drop-in-ui' => [
        'title' => 'रेज़रपे',
    ],

    'response' => [
        'payment' => [
            'cancelled' => 'Razorpay भुगतान रद्द कर दिया गया है।',
        ],

        'something-went-wrong'     => 'कुछ गलत हो गया।',
        'supported-currency-error' => 'मुद्रा :currency समर्थित नहीं है। समर्थित मुद्राएँ: :supportedCurrencies.',
    ],
];
