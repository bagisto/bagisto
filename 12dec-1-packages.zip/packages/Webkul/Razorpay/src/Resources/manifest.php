<?php

return [
    'name'    => 'Webkul Bagisto Razorpay',
    'version' => core()->version(),
];
