<?php

namespace Webkul\Razorpay\Tests;

use Tests\TestCase;
use Webkul\Payment\Tests\Concerns\ProvidePaymentHelpers;

class RazorpayTestCase extends TestCase
{
    use ProvidePaymentHelpers;
}
