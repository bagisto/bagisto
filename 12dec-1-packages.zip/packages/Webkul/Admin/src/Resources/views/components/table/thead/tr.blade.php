<tr {{ $attributes->merge(['scope' => 'row', 'class' => 'dark:border-gray-800']) }}>
    {{ $slot }}
</tr>
