@for ($i = 0; $i < 3; $i++)
    <div class="border-b border-slate-300 p-4 dark:border-gray-800">
        <p class="shimmer h-[17px] w-[150px]"></p>
    </div>
@endfor